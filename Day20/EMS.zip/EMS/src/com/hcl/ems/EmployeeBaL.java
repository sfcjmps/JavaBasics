package com.hcl.ems;

public class EmployeeBaL {
	public static Employee showEmployeeBal(int emp_id) {
		return new EmloyeeDaO().showEmployee(emp_id);
	}
}
